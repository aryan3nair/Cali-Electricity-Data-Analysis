# California-Electricity-Study
analysis of hourly electricity data in California
